<?php
include_once dirname(__FILE__) . '/functions/register-scripts.php';
include_once dirname(__FILE__) . '/functions/register-menus.php';
include_once dirname(__FILE__) . '/functions/acf.php';
include_once dirname(__FILE__) . '/functions/shortcodes.php';
include_once dirname(__FILE__) . '/functions/login-form.php';
include_once dirname(__FILE__) . '/functions/login.php';
include_once dirname(__FILE__) . '/functions/admin.php';
include_once dirname(__FILE__) . '/functions/schema-markup.php';
//include_once dirname(__FILE__) . '/functions/neacobox.php';
include_once dirname(__FILE__) . '/functions/yoda.php';
?>