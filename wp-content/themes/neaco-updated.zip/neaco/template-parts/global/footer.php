<footer class="footer">
	<?php get_template_part('template-parts/global/footer/social'); ?>
	<?php get_template_part('template-parts/global/footer/main'); ?>
	<?php get_template_part('template-parts/global/footer/base'); ?>
</footer>