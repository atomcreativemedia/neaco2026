<section class="careers__main">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-11 col-md-4">
				<?php get_template_part('template-parts/templates/careers/filters'); ?>
			</div>
			<div class="col-11 col-md-8">
				<?php get_template_part('template-parts/templates/careers/items'); ?>
			</div>
		</div>
	</div>
</section>