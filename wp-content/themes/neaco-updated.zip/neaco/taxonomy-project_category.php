<?php get_header(); ?>
<main class="projects project-category">
	<?php get_template_part('template-parts/sections/page-heading'); ?>
	<?php get_template_part('template-parts/templates/projects/categories'); ?>
	<?php get_template_part('template-parts/templates/projects/description'); ?>
	<?php get_template_part('template-parts/templates/projects/projects'); ?>
</main>
<?php get_footer(); ?>