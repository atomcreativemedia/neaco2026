<?php
/*********
Bring In Shortcode Functions
*********/
include_once dirname(__FILE__) . '/shortcodes/shortcodes.php';